from multiprocessing import context
from django.shortcuts import redirect, render
from .forms import ClientForm
from .models import Client
# Create your views here.
def creer_client(request):
        form=ClientForm()
        if request.method=='POST':
                form=ClientForm(request.POST)
                if form.is_valid():
                        form.save()
                        return redirect('/')

        context={'form':form}
        return render(request,'client/creer_client.html', context)
