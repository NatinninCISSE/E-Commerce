from django.db import models

# Create your models here.

class Client(models.Model):
    Nom_Client=models.CharField(max_length=200, null=True)
    Prenom_Client=models.CharField(max_length=200, null=True)
    Numero_Client=models.FloatField(max_length=15, null=True)
    Mail_Client=models.EmailField(max_length=200, null=True)
    Adresse_Client=models.CharField(max_length=200, null=True)
