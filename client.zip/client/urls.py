
from django.urls import path
from . import views

urlpatterns = [
    path('ajout_client', views.creer_client, name='ajout_client'),

]
