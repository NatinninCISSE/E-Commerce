from multiprocessing import context
from django.shortcuts import redirect, render
from django.http import HttpResponse

from .models import Commande
# Create your views here.

def supprimer_commande(request,pk):

        commande=Commande.objects.get(id=pk)

        if request.method=='POST':

                commande.delete()
                return redirect('/')

        context={'item':commande}

        return render(request, context)
