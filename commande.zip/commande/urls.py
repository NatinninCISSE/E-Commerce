from django.urls import path
from . import views

urlpatterns = [

    path('supprimer_commande/<str:pk>', views.supprimer_commande, name='supprimer_commande'),


]
