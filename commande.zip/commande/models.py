from secrets import choice
from telnetlib import STATUS
from django.db import models
from client.models import Client
from myapp.models import Produit

# Create your models here.



class Commande(models.Model):
    STATUS = [
        ('en instance','en instance'),
        ('livré','livré'),
        ('non livre','non livré')
    ]

    Client=models.ForeignKey(Client,null=True,on_delete=models.SET_NULL)
    Produit=models.ForeignKey(Produit,null=True,on_delete=models.SET_NULL)

    status=models.CharField(max_length=200,null=True, choices=STATUS)
    Dat_Crea_Commande=models.DateTimeField(auto_now_add=True)